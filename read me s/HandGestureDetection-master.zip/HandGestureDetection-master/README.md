# Hand Gesture Detection

# Demo Video
[![ScreenShot](https://github.com/InderPabla/HandGestureDetection/blob/master/Images/3.png)](https://youtu.be/Y6oLbRKwmPk)

# Playing Mario With Hand Gestures
[![ScreenShot](https://github.com/InderPabla/HandGestureDetection/blob/master/Images/4.png)](https://youtu.be/HaQizxcc1d0)

## Convolutional Neural Network learning to detect between 7 different static hand gestures, +1 None for no hand detected
![](https://github.com/InderPabla/HandGestureDetection/blob/master/Images/2.gif)
